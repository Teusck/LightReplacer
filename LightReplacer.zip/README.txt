1.Extraia todos os arquivos para uma pasta de instalação.

2.Abra o arquivo "LightReplacer.exe" ou o atalho "LightReplacer".

##################################################################

Bugs conhecidos !ATENÇÃO!:

1.Ao colocar frases, é possível que corrompa o tipo de arquivo, tendo que renomea-lo manualmente.

2.Tradução não funciona após a utilização do "Renomear". 

